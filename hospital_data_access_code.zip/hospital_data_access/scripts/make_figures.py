"""Render compact timing plots from completed measurements."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
results = ROOT / "results"
df = pd.read_csv(results / "performance_summary.csv")
figures = results / "figures"
figures.mkdir(exist_ok=True)

for filename, metrics, title in (
    ("encryption.png", ["online_encrypt_ms", "direct_encrypt_ms"], "Encryption work by policy size"),
    ("access.png", ["edge_transform_ms", "user_recovery_ms", "direct_decrypt_ms"], "Decryption work by policy size"),
    ("integrity.png", ["preverify_ms"], "Ciphertext integrity verification"),
    ("ciphertext_size.png", ["ciphertext_bytes"], "Serialized ciphertext size"),
):
    fig, ax = plt.subplots(figsize=(7.5, 4.3))
    for name in metrics:
        rows = df[df.metric == name].sort_values("policy_rows")
        ax.errorbar(rows.policy_rows, rows["mean"],
                    yerr=[rows["mean"] - rows.ci95_low, rows.ci95_high - rows["mean"]],
                    capsize=3, marker="o", label=name.replace("_", " "))
    ax.set_xlabel("Policy attributes")
    ax.set_ylabel("Bytes" if filename == "ciphertext_size.png" else "Milliseconds")
    ax.set_title(title)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(figures / filename, dpi=160)
    plt.close(fig)
print("Figures created in", figures)
