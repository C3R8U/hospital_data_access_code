"""Print the measured policy cost table and backend limitations."""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
summary = pd.read_csv(ROOT / "results/performance_summary.csv")
metrics = json.loads((ROOT / "results/metrics.json").read_text())
subset = summary[summary.metric.isin(["online_encrypt_ms", "preverify_ms", "edge_transform_ms", "user_recovery_ms"])]
print(subset.pivot(index="policy_rows", columns="metric", values="mean").round(5).to_string())
print("\nData records:", metrics["dataset_profile"]["records"])
print("Group backend:", metrics["backend"])
print("Physical pairing execution:", metrics["physical_pairings_measured"])
print("Fabric TPS:", metrics["fabric_tps"])
print("Local metadata pipeline TPS:", round(metrics["local_storage_pipeline_tps_not_fabric"], 4))
