#!/usr/bin/env bash
set -euo pipefail
mkdir -p build
cc -O2 -fPIC -shared -o build/libhealthshare_pbc.so native/pbc_bridge.c -lpbc -lgmp
cc -O2 -o build/setup_a1 native/setup_a1.c -lpbc -lgmp
printf 'Native PBC tools were built in ./build\n'
