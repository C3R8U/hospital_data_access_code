"""Upload prepared ciphertexts to an IPFS node and update their storage references."""
import argparse
import json
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def put_file(endpoint, file_path):
    boundary = "----hospital-share-object-upload"
    data = file_path.read_bytes()
    header = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
              f"filename=\"{file_path.name}\"\r\nContent-Type: application/octet-stream\r\n\r\n").encode()
    footer = f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(endpoint.rstrip("/") + "/api/v0/add?pin=true",
        data=header + data + footer, method="POST",
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=120) as response:
        result = json.loads(response.read())
    if not result.get("Hash"):
        raise RuntimeError("The IPFS node did not return a content identifier")
    return "ipfs://" + result["Hash"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--endpoint", default="http://127.0.0.1:5001")
    args = parser.parse_args()
    file = ROOT / "data/derived/fabric_transactions.jsonl"
    if not file.exists(): raise FileNotFoundError("Run build_fabric_workload.py first")
    items = [json.loads(line) for line in file.read_text().splitlines() if line]
    for item in items:
        if item["storage_uri"].startswith("ipfs://"): continue
        local_file = Path(item["storage_uri"].removeprefix("file://"))
        item["storage_uri"] = put_file(args.endpoint, local_file)
    file.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in items))
    print(f"Uploaded {len(items)} encrypted objects to IPFS")

if __name__ == "__main__": main()
