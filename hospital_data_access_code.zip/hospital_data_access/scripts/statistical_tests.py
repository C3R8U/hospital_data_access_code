"""Paired comparisons use the same access policy and record in every trial."""
from pathlib import Path
import pandas as pd
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]
data = pd.read_csv(ROOT / "results/performance_raw.csv")
results = []
for size, trials in data.groupby("policy_rows"):
    online, direct = trials.online_encrypt_ms.to_numpy(), trials.direct_encrypt_ms.to_numpy()
    p = wilcoxon(direct - online, alternative="greater").pvalue
    results.append({"policy_rows": int(size), "comparison": "direct_encrypt_vs_cached_online",
                    "paired_count": len(trials), "p_value": float(p),
                    "mean_direct_ms": direct.mean(), "mean_online_ms": online.mean()})
    cost = trials.edge_transform_ms.to_numpy() + trials.user_recovery_ms.to_numpy()
    p2 = wilcoxon(trials.direct_decrypt_ms.to_numpy() - cost,
                  alternative="two-sided").pvalue
    results.append({"policy_rows": int(size), "comparison": "direct_decrypt_vs_transform_plus_recovery",
                    "paired_count": len(trials), "p_value": float(p2),
                    "mean_direct_ms": trials.direct_decrypt_ms.mean(),
                    "mean_online_ms": cost.mean()})
output = pd.DataFrame(results)
# Holm correction accounts for the ten planned hypothesis tests.
output = output.sort_values("p_value").reset_index(drop=True)
m = len(output)
corrected = [min(1.0, (m - i) * p) for i, p in enumerate(output.p_value)]
for i in range(1, len(corrected)):
    corrected[i] = max(corrected[i], corrected[i-1])
output["p_holm"] = corrected
output.sort_values(["policy_rows", "comparison"]).to_csv(
    ROOT / "results/paired_tests.csv", index=False)
print("Paired tests saved to results/paired_tests.csv")
