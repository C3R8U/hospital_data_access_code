"""Creates an A1 parameter set without retaining prime factors in the output."""
import argparse
import os
import secrets
import subprocess
import tempfile
from pathlib import Path
from sympy import isprime


def new_prime(bits):
    while True:
        candidate = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if isprime(candidate): return candidate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bits", type=int, default=1024)
    parser.add_argument("--output", default="params/public")
    parser.add_argument("--generator", default="build/setup_a1")
    args = parser.parse_args()
    if args.bits < 1024:
        raise ValueError("Choose at least 1024 bits for each subgroup prime")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    factors = [new_prime(args.bits) for _ in range(3)]
    if len(set(factors)) != 3: raise RuntimeError("Prime generation repeated a factor")
    with tempfile.NamedTemporaryFile(mode="w", delete=False) as private:
        os.chmod(private.name, 0o600)
        for p in factors: private.write(str(p) + "\n")
        private_path = private.name
    try:
        subprocess.run([args.generator, private_path, str(out / "a1.param"),
                        str(out / "g1.bin")], check=True)
    finally:
        os.unlink(private_path)
        del factors
    print("Public pairing configuration generated; private factors were not exported")
    print("Evaluate the concrete curve and target-field strength before deploying")

if __name__ == "__main__": main()
