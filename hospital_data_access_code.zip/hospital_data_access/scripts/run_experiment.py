"""Run clinical access-policy workloads and save measurement files."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.experiments import run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["algebra-check", "pbc-a1"], default=None)
    parser.add_argument("--repetitions", type=int, default=None)
    args = parser.parse_args()
    config = json.loads((ROOT / "config/study.json").read_text(encoding="utf-8"))
    print(json.dumps(run(ROOT, config, args.backend or config["backend"], args.repetitions), indent=2))

if __name__ == "__main__": main()
