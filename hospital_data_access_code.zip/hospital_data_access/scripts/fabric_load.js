'use strict';
// Each successful submit waits for a commit status from the peer gateway.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const grpc = require('@grpc/grpc-js');
const { connect, signers } = require('@hyperledger/fabric-gateway');

async function main() {
  const required = ['FABRIC_PEER_ENDPOINT', 'FABRIC_TLS_CERT', 'FABRIC_CLIENT_CERT',
                    'FABRIC_CLIENT_KEY', 'FABRIC_MSP_ID'];
  for (const name of required) {
    if (!process.env[name]) throw new Error(`Required environment variable: ${name}`);
  }
  const endpoint = process.env.FABRIC_PEER_ENDPOINT;
  const tls = fs.readFileSync(process.env.FABRIC_TLS_CERT);
  const cert = fs.readFileSync(process.env.FABRIC_CLIENT_CERT);
  const key = crypto.createPrivateKey(fs.readFileSync(process.env.FABRIC_CLIENT_KEY));
  const client = new grpc.Client(endpoint, grpc.credentials.createSsl(tls), {
    'grpc.ssl_target_name_override': process.env.FABRIC_PEER_HOSTNAME || endpoint.split(':')[0],
  });
  const gateway = connect({
    client,
    identity: { mspId: process.env.FABRIC_MSP_ID, credentials: cert },
    signer: signers.newPrivateKeySigner(key),
    commitStatusOptions: () => ({ deadline: Date.now() + 30000 }),
  });
  const channels = (process.env.FABRIC_CHANNELS || 'clinical,laboratory,administrative').split(',');
  const contractName = process.env.FABRIC_CHAINCODE || 'hospitalmeta';
  const contracts = channels.map(ch => gateway.getNetwork(ch).getContract(contractName));
  const loads = (process.env.FABRIC_LOADS || '500,1000,2000,3000,4000').split(',').map(Number);
  const templatesFile = process.env.FABRIC_TX_FILE || path.join(__dirname, '..', 'data/derived/fabric_transactions.jsonl');
  const templates = fs.readFileSync(templatesFile, 'utf8').trim().split('\n').map(line => JSON.parse(line));
  if (!templates.length) throw new Error('No encrypted metadata entries were found');
  if (process.env.FABRIC_REQUIRE_IPFS === '1' && templates.some(x => !x.storage_uri.startsWith('ipfs://'))) {
    throw new Error('Upload all encrypted objects to IPFS before the complete workflow test');
  }
  const durationMs = Number(process.env.FABRIC_DURATION_MS || 60000);
  const repetitions = Number(process.env.FABRIC_REPETITIONS || 10);
  const concurrency = Number(process.env.FABRIC_IN_FLIGHT || 32);
  const outcomes = [];

  for (const rate of loads) {
    for (let repeat = 0; repeat < repetitions; repeat++) {
      let issued = 0, committed = 0, failed = 0;
      const started = performance.now();
      const outstanding = new Set();
      const totalRequests = Math.floor(rate * durationMs / 1000);
      async function submit(index) {
        const template = templates[index % templates.length];
        const channel = template.channel;
        const channelIndex = channels.indexOf(channel);
        if (channelIndex < 0) throw new Error(`Missing channel contract: ${channel}`);
        const contract = contracts[channelIndex];
        const id = `${template.object_id}-${rate}-${repeat}-${index}`;
        const statement = JSON.stringify({ object_id: id, digest: template.digest,
          policy_digest: template.policy_digest, storage_uri: template.storage_uri,
          channel, version: template.version });
        const signature = crypto.sign('sha256', Buffer.from(statement), key).toString('base64');
        try {
          await contract.submitTransaction('PutMetadata', id, template.digest, template.policy_digest,
              template.storage_uri, channel, template.version, signature);
          committed++;
        } catch (err) {
          failed++;
        }
      }
      for (let i = 0; i < totalRequests; i++) {
        const intendedTime = started + (i * 1000 / rate);
        const wait = intendedTime - performance.now();
        if (wait > 1) await new Promise(resolve => setTimeout(resolve, wait));
        while (outstanding.size >= concurrency) await Promise.race(outstanding);
        issued++;
        const pending = submit(i).finally(() => outstanding.delete(pending));
        outstanding.add(pending);
      }
      await Promise.allSettled([...outstanding]);
      const elapsedS = (performance.now() - started) / 1000;
      const report = { request_rate: rate, repetition: repeat, channels: channels.length,
                       issued, committed, failed, duration_s: elapsedS,
                       committed_tps: committed / elapsedS };
      outcomes.push(report);
      console.log(JSON.stringify(report));
    }
  }
  fs.mkdirSync(path.join(__dirname, '..', 'results'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, '..', 'results', 'fabric_commits.json'),
                   JSON.stringify(outcomes, null, 2));
  gateway.close(); client.close();
}
main().catch(err => { console.error(err.message); process.exitCode = 1; });
