"""Record input checksums and the packages used to run experiments."""
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError
import hashlib
import json
import os
import platform

ROOT = Path(__file__).resolve().parents[1]
files = [ROOT / "data/raw/diabetic_data.csv", ROOT / "data/raw/IDS_mapping.csv",
         ROOT / "config/study.json"]
checksums = {}
for file in files:
    h = hashlib.sha256()
    with file.open("rb") as inp:
        for block in iter(lambda: inp.read(1024*1024), b""):
            h.update(block)
    checksums[str(file.relative_to(ROOT))] = h.hexdigest()
packages = {}
for name in ["numpy", "pandas", "scipy", "cryptography", "matplotlib", "pytest"]:
    try: packages[name] = version(name)
    except PackageNotFoundError: packages[name] = None
manifest = {"input_sha256": checksums, "packages": packages,
            "python": platform.python_version(), "platform": platform.platform(),
            "executed_cpu_count": os.cpu_count()}
(ROOT / "results/manifest.json").write_text(json.dumps(manifest, indent=2))
print("Source hashes and runtime packages saved")
