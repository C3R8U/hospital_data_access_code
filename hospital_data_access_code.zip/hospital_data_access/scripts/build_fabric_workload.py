"""Prepare encrypted metadata records from observed clinical encounters."""
import argparse
import base64
import hashlib
import json
import random
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.groups import AlgebraGroup, PBCGroup
from healthshare.data import load_data, add_bins, build_catalog, record_attributes, patient_payload, sample_records
from healthshare.policy import build_policy
from healthshare.abe import AccessEngine


def main():
    arg = argparse.ArgumentParser()
    arg.add_argument("--count", type=int, default=150)
    arg.add_argument("--backend", choices=["algebra-check", "pbc-a1"], default="algebra-check")
    opts = arg.parse_args()
    cfg = json.loads((ROOT / "config/study.json").read_text())
    df = add_bins(load_data(ROOT / cfg["data_file"]))
    universe, _ = build_catalog(df)
    G = (AlgebraGroup(cfg["seed"] + 1000) if opts.backend == "algebra-check" else
         PBCGroup(ROOT / cfg["native_pairing_parameter_file"],
                  ROOT / cfg["native_public_generator_file"], ROOT / "build/libhealthshare_pbc.so"))
    engine = AccessEngine(G, universe, cfg["authority_count"],
                          cfg["max_matrix_columns"], cfg["cache_depth"])
    engine.initialize_cache()
    rng = random.Random(cfg["seed"] + 8)
    out_dir = ROOT / "data/derived/fabric_ciphertexts"
    out_dir.mkdir(parents=True, exist_ok=True)
    output = ROOT / "data/derived/fabric_transactions.jsonl"
    with output.open("w", encoding="utf-8") as dest:
        for index, (row_num, row) in enumerate(sample_records(df, opts.count, cfg["seed"] + 8)):
            channel = cfg["fabric_channels"][index % len(cfg["fabric_channels"])]
            held = record_attributes(row, universe, channel)
            size = cfg["policy_sizes"][index % len(cfg["policy_sizes"])]
            policy = build_policy(universe, held, size, cfg["policy_clause_size"], rng)
            if not engine.cache: engine.refill_one()
            package, _, _ = engine.create(policy,
                patient_payload(row, cfg["cipher_payload_bytes"]), channel=channel)
            identifier = hashlib.sha256(f"{cfg['seed']}:{row_num}:{channel}".encode()).hexdigest()[:32]
            name = f"{identifier}.bin"
            file_path = out_dir / name
            file_path.write_bytes(package.record)
            data = json.loads(package.record)
            item = {
                "object_id": identifier, "channel": channel, "digest": hashlib.sha256(package.record).hexdigest(),
                "policy_digest": json.loads(package.associated)["policy_digest"],
                "storage_uri": file_path.resolve().as_uri(),
                "version": "1", "owner_signature": base64.b64encode(package.signature).decode(),
                "ciphertext_bytes": len(package.record), "source_row": row_num,
                "policy_rows": size, "backend": G.name,
            }
            dest.write(json.dumps(item, sort_keys=True) + "\n")
    print(f"Wrote {opts.count} encrypted metadata entries to {output}")
    print("File URIs are local storage references, not IPFS content addresses")
    if hasattr(G, "close"): G.close()

if __name__ == "__main__": main()
