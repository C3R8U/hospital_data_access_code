package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type MetadataContract struct {
	contractapi.Contract
}

type DataReference struct {
	ObjectID       string `json:"object_id"`
	Digest         string `json:"digest"`
	PolicyDigest   string `json:"policy_digest"`
	StorageURI     string `json:"storage_uri"`
	ChannelID      string `json:"channel_id"`
	Version        string `json:"version"`
	OwnerSignature string `json:"owner_signature"`
	Revoked        bool   `json:"revoked"`
}

func (c *MetadataContract) PutMetadata(ctx contractapi.TransactionContextInterface,
	objectID, digest, policyDigest, storageURI, channelID, version, ownerSignature string) error {
	if objectID == "" || len(digest) != 64 || len(policyDigest) != 64 || version == "" {
		return errors.New("invalid metadata fields")
	}
	if strings.TrimSpace(storageURI) == "" || strings.TrimSpace(ownerSignature) == "" {
		return errors.New("storage reference or owner signature is missing")
	}
	actualChannel := ctx.GetStub().GetChannelID()
	if channelID != actualChannel {
		return fmt.Errorf("channel mismatch: %s", channelID)
	}
	existing, err := ctx.GetStub().GetState(objectID)
	if err != nil {
		return err
	}
	if existing != nil {
		return errors.New("object already exists")
	}
	item := DataReference{objectID, digest, policyDigest, storageURI, channelID,
		version, ownerSignature, false}
	blob, err := json.Marshal(item)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(objectID, blob)
}

func (c *MetadataContract) GetMetadata(ctx contractapi.TransactionContextInterface,
	objectID string) (*DataReference, error) {
	blob, err := ctx.GetStub().GetState(objectID)
	if err != nil {
		return nil, err
	}
	if blob == nil {
		return nil, errors.New("object not found")
	}
	var entry DataReference
	if err := json.Unmarshal(blob, &entry); err != nil {
		return nil, err
	}
	return &entry, nil
}

func (c *MetadataContract) InvalidateMetadata(ctx contractapi.TransactionContextInterface,
	objectID string) error {
	item, err := c.GetMetadata(ctx, objectID)
	if err != nil {
		return err
	}
	item.Revoked = true
	blob, err := json.Marshal(item)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(objectID, blob)
}

func main() {
	chaincode, err := contractapi.NewChaincode(&MetadataContract{})
	if err != nil {
		panic(err)
	}
	if err := chaincode.Start(); err != nil {
		panic(err)
	}
}
