"""Group arithmetic for attribute keys and policy ciphertexts."""
from __future__ import annotations
import ctypes
import hashlib
import secrets
from dataclasses import dataclass
from pathlib import Path

TEST_ORDER = 2**127 - 1

@dataclass(frozen=True)
class Element:
    kind: str
    power: int

class AlgebraGroup:
    """Checks pairing identities using exponents; does not provide secure pairings."""
    name = "algebra-check"
    secure = False

    def __init__(self, seed=0):
        import random
        self._rng = random.Random(seed)
        self.order = TEST_ORDER

    def generator(self): return Element("G", 1)
    def identity(self, kind): return Element(kind, 0)
    def base_pair(self): return Element("GT", 1)
    def random_scalar(self, invertible=False): return self._rng.randrange(1, self.order)
    def random_target(self): return Element("GT", self.random_scalar())
    def identity_hash(self, gid):
        value = hashlib.sha256(b"ID:" + gid.encode()).digest()
        return Element("G", int.from_bytes(value, "big") % self.order)
    def mul(self, a, b):
        assert a.kind == b.kind
        return Element(a.kind, (a.power + b.power) % self.order)
    def div(self, a, b):
        assert a.kind == b.kind
        return Element(a.kind, (a.power - b.power) % self.order)
    def pow(self, a, v): return Element(a.kind, a.power * v % self.order)
    def pair(self, a, b):
        assert a.kind == b.kind == "G"
        return Element("GT", a.power * b.power % self.order)
    def serialize(self, a): return a.kind.encode() + b":" + a.power.to_bytes(16, "big")
    def equal(self, a, b): return a == b
    def deserialize(self, blob):
        kind, data = blob.split(b":", 1)
        kind = kind.decode("ascii")
        if kind not in ("G", "GT") or len(data) != 16:
            raise ValueError("Invalid algebra element")
        return Element(kind, int.from_bytes(data, "big") % self.order)

class NativeElement:
    def __init__(self, address, kind):
        if not address:
            raise RuntimeError("Native group operation failed")
        self.pointer = ctypes.c_void_p(address)
        self.kind = kind

class PBCGroup:
    """Connects Python policy operations to a PBC A1 pairing group."""
    name = "pbc-a1"
    secure = None  # Parameter security is assessed separately from API correctness.

    def __init__(self, parameter_path, generator_path, library_path):
        self.api = ctypes.CDLL(str(Path(library_path).resolve()))
        self._bind()
        self.context = self.api.hs_open(str(parameter_path).encode(), str(generator_path).encode())
        if not self.context:
            raise RuntimeError("The pairing parameters or public generator are unavailable")
        self.order = int(self.api.hs_order(self.context).decode(), 16)
        self.g = NativeElement(self.api.hs_generator(self.context), "G")
        self.unit_g = NativeElement(self.api.hs_identity(self.context, 1), "G")
        self.unit_gt = NativeElement(self.api.hs_identity(self.context, 2), "GT")

    def _bind(self):
        a = self.api
        a.hs_open.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        a.hs_open.restype = ctypes.c_void_p
        a.hs_close.argtypes = [ctypes.c_void_p]
        a.hs_order.argtypes = [ctypes.c_void_p]
        a.hs_order.restype = ctypes.c_char_p
        a.hs_generator.argtypes = [ctypes.c_void_p]
        a.hs_generator.restype = ctypes.c_void_p
        a.hs_identity.argtypes = [ctypes.c_void_p, ctypes.c_int]
        a.hs_identity.restype = ctypes.c_void_p
        for name in ("hs_mul", "hs_div", "hs_pair"):
            fn = getattr(a, name)
            fn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
            fn.restype = ctypes.c_void_p
        a.hs_pow.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p]
        a.hs_pow.restype = ctypes.c_void_p
        a.hs_gid_hash.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        a.hs_gid_hash.restype = ctypes.c_void_p
        a.hs_random_target.argtypes = [ctypes.c_void_p]
        a.hs_random_target.restype = ctypes.c_void_p
        a.hs_byte_length.argtypes = [ctypes.c_void_p]
        a.hs_byte_length.restype = ctypes.c_int
        a.hs_to_bytes.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
        a.hs_to_bytes.restype = ctypes.c_int
        a.hs_from_bytes.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
        a.hs_from_bytes.restype = ctypes.c_void_p

    def generator(self): return self.g
    def identity(self, kind): return self.unit_g if kind == "G" else self.unit_gt
    def base_pair(self): return self.pair(self.g, self.g)
    def random_scalar(self, invertible=False):
        import math
        while True:
            n = secrets.randbelow(self.order - 1) + 1
            if not invertible or math.gcd(n, self.order) == 1:
                return n
    def random_target(self): return NativeElement(self.api.hs_random_target(self.context), "GT")
    def identity_hash(self, gid): return NativeElement(self.api.hs_gid_hash(self.context, gid.encode()), "G")
    def _binary(self, fn, a, b, kind):
        return NativeElement(getattr(self.api, fn)(self.context, a.pointer, b.pointer), kind)
    def mul(self, a, b):
        assert a.kind == b.kind
        return self._binary("hs_mul", a, b, a.kind)
    def div(self, a, b):
        assert a.kind == b.kind
        return self._binary("hs_div", a, b, a.kind)
    def pair(self, a, b):
        assert a.kind == b.kind == "G"
        return self._binary("hs_pair", a, b, "GT")
    def pow(self, a, exponent):
        p = self.api.hs_pow(self.context, a.pointer, str(exponent % self.order).encode())
        return NativeElement(p, a.kind)
    def serialize(self, e):
        size = self.api.hs_byte_length(e.pointer)
        if size <= 0: raise RuntimeError("Invalid native element size")
        buffer = ctypes.create_string_buffer(size)
        if self.api.hs_to_bytes(e.pointer, buffer, size) != size:
            raise RuntimeError("Native serialization failed")
        return e.kind.encode() + b":" + buffer.raw
    def equal(self, a, b): return self.serialize(a) == self.serialize(b)
    def deserialize(self, blob):
        kind, data = blob.split(b":", 1)
        kind = kind.decode("ascii")
        if kind not in ("G", "GT"):
            raise ValueError("Invalid PBC element type")
        buffer = ctypes.create_string_buffer(data)
        value = self.api.hs_from_bytes(self.context, 1 if kind == "G" else 2, buffer, len(data))
        return NativeElement(value, kind)
    def close(self):
        if self.context:
            self.api.hs_close(self.context)
            self.context = None
