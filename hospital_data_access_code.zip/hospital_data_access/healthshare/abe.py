"""Multi-authority encryption, one-use offline slots, and blinded recovery."""
from __future__ import annotations
import base64
import hashlib
import json
import secrets
import time
from dataclasses import dataclass
from .policy import Policy
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def b64(blob): return base64.b64encode(blob).decode("ascii")
def canonical(obj): return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()

@dataclass
class AttributeKeys:
    alpha: int
    y: int
    A: object
    B: object
    authority: int

@dataclass
class Slot:
    v: list[int]
    w: list[int]
    E: list[object]
    W: list[object]
    attr_parts: dict

@dataclass
class Package:
    policy: object
    rows: list[tuple]
    c0: object
    encrypted: bytes
    nonce: bytes
    associated: bytes
    confirmation: str
    record: bytes
    signature: bytes
    signer_public: object

class AccessEngine:
    def __init__(self, group, universe, authorities=4, max_columns=16, cache_depth=8):
        self.group = group
        self.universe = list(universe)
        self.max_columns = max_columns
        self.cache_depth = cache_depth
        self.g = group.generator()
        self.eg = group.base_pair()
        self.attributes = {}
        for i, attr in enumerate(self.universe):
            alpha, y = group.random_scalar(), group.random_scalar()
            self.attributes[attr] = AttributeKeys(alpha, y, group.pow(self.eg, alpha),
                                                   group.pow(self.g, y), i % authorities)
        self.signer = Ed25519PrivateKey.generate()
        self.cache = []

    def issue_user_keys(self, gid, attributes):
        H = self.group.identity_hash(gid)
        keys = {}
        for attr in sorted(attributes):
            k = self.attributes[attr]
            keys[attr] = self.group.mul(self.group.pow(self.g, k.alpha),
                                        self.group.pow(H, k.y))
        return H, keys

    def precompute(self):
        G = self.group
        D = self.max_columns
        v = [G.random_scalar() for _ in range(D)]
        w = [0] + [G.random_scalar() for _ in range(D - 1)]
        E = [G.pow(self.eg, x) for x in v]
        W = [G.identity("G")] + [G.pow(self.g, x) for x in w[1:]]
        parts = {}
        for attr, key in self.attributes.items():
            r = G.random_scalar()
            parts[attr] = (G.pow(key.A, r), G.pow(self.g, r), G.pow(key.B, r))
        return Slot(v, w, E, W, parts)

    def initialize_cache(self):
        start = time.perf_counter_ns()
        self.cache = [self.precompute() for _ in range(self.cache_depth)]
        return (time.perf_counter_ns() - start) / 1e6

    def take_slot(self):
        if not self.cache:
            return self.precompute(), False
        return self.cache.pop(), True

    def refill_one(self):
        start = time.perf_counter_ns()
        if len(self.cache) < self.cache_depth:
            self.cache.append(self.precompute())
        return (time.perf_counter_ns() - start) / 1e6

    def create(self, policy, message, channel="clinical", from_cache=True):
        G = self.group
        if policy.column_count > self.max_columns:
            raise ValueError("The matrix exceeds the configured offline vector size")
        slot, hit = self.take_slot() if from_cache else (self.precompute(), False)
        start = time.perf_counter_ns()
        rows = []
        for matrix_row, attr in zip(policy.matrix, policy.labels):
            X, Y, Z = slot.attr_parts[attr]
            c1, c3 = X, Z
            for col, value in enumerate(matrix_row):
                if value:
                    power = slot.E[col] if value > 0 else G.div(G.identity("GT"), slot.E[col])
                    c1 = G.mul(c1, power)
                if value and col > 0:
                    power = slot.W[col] if value > 0 else G.div(G.identity("G"), slot.W[col])
                    c3 = G.mul(c3, power)
            rows.append((c1, Y, c3))
        R = G.random_target()
        c0 = G.mul(R, slot.E[0])
        salt = secrets.token_bytes(16)
        digest = hashlib.sha256(salt + canonical(policy.export())).hexdigest()
        associated = canonical({"channel": channel, "policy_digest": digest, "version": 1})
        key = self._key(R, associated)
        nonce = secrets.token_bytes(12)
        encrypted = AESGCM(key).encrypt(nonce, message, associated)
        confirmation = self._confirm(R, associated)
        details = {
            "policy": policy.export(), "rows": [
                [b64(G.serialize(x)) for x in triplet] for triplet in rows],
            "c0": b64(G.serialize(c0)), "encrypted": b64(encrypted),
            "nonce": b64(nonce), "associated": b64(associated),
            "salt": b64(salt), "confirmation": confirmation,
        }
        record = canonical(details)
        signature = self.signer.sign(record)
        elapsed_ms = (time.perf_counter_ns() - start) / 1e6
        package = Package(policy, rows, c0, encrypted, nonce, associated,
                          confirmation, record, signature, self.signer.public_key())
        return package, elapsed_ms, hit


    def load_signed_package(self, record, signature, trusted_public_key):
        # Verify the owner signature before decoding any group element.
        trusted_public_key.verify(signature, record)
        data = json.loads(record)
        raw_policy = data["policy"]
        policy = Policy(raw_policy["matrix"], raw_policy["labels"], raw_policy["clauses"])
        if len(data["rows"]) != policy.row_count:
            raise ValueError("Ciphertext and policy row counts disagree")
        G = self.group
        rows = [tuple(G.deserialize(base64.b64decode(value)) for value in triplet)
                for triplet in data["rows"]]
        package = Package(
            policy, rows, G.deserialize(base64.b64decode(data["c0"])),
            base64.b64decode(data["encrypted"]), base64.b64decode(data["nonce"]),
            base64.b64decode(data["associated"]), data["confirmation"],
            record, signature, trusted_public_key)
        if not self.preverify(package, trusted_public_key=trusted_public_key):
            raise ValueError("Invalid package metadata")
        return package

    def _key(self, R, associated):
        return HKDF(algorithm=hashes.SHA256(), length=16, salt=None,
                    info=b"hospital-share:key:" + associated).derive(self.group.serialize(R))

    def _confirm(self, R, associated):
        return hashlib.sha256(b"hospital-share:confirm:" + self.group.serialize(R)
                              + associated).hexdigest()

    def preverify(self, package, expected_channel="clinical", trusted_public_key=None):
        try:
            verifier = trusted_public_key if trusted_public_key is not None else self.signer.public_key()
            verifier.verify(package.signature, package.record)
            data = json.loads(package.record)
            if data["associated"] != b64(package.associated): return False
            ad = json.loads(package.associated)
            if ad["channel"] != expected_channel or ad["version"] != 1: return False
            policy_digest = hashlib.sha256(base64.b64decode(data["salt"])
                                             + canonical(package.policy.export())).hexdigest()
            if ad["policy_digest"] != policy_digest: return False
            if data["policy"] != package.policy.export(): return False
            if data["c0"] != b64(self.group.serialize(package.c0)): return False
            if data["rows"] != [[b64(self.group.serialize(e)) for e in row]
                                 for row in package.rows]: return False
            if data["encrypted"] != b64(package.encrypted): return False
            if data["nonce"] != b64(package.nonce): return False
            if data["confirmation"] != package.confirmation: return False
            return True
        except (ValueError, TypeError, KeyError, IndexError):
            return False
        except Exception:
            return False

    def blind(self, gid, keys):
        group = self.group
        z = group.random_scalar(invertible=True)
        inverse = pow(z, -1, group.order)
        return z, group.pow(group.identity_hash(gid), inverse), {
            name: group.pow(key, inverse) for name, key in keys.items()}

    def transform(self, package, blinded_h, blinded_keys):
        coeff = package.policy.witness(set(blinded_keys))
        if coeff is None: raise PermissionError("The attribute set does not satisfy the access policy")
        G = self.group
        result = G.identity("GT")
        for i, weight in enumerate(coeff):
            if weight == 0: continue
            c1, c2, c3 = package.rows[i]
            attr = package.policy.labels[i]
            ratio = G.div(G.pair(blinded_h, c3), G.pair(blinded_keys[attr], c2))
            result = G.mul(result, G.pow(ratio, weight))
        return result

    def recover(self, package, P, z, attributes):
        G = self.group
        coeff = package.policy.witness(set(attributes))
        if coeff is None: raise PermissionError("Access policy not satisfied")
        L = G.identity("GT")
        for i, weight in enumerate(coeff):
            if weight: L = G.mul(L, G.pow(package.rows[i][0], weight))
        recovered = G.div(package.c0, G.mul(L, G.pow(P, z)))
        # The transform uses the negative of the masked attribute terms.
        # C0 / (L * P^z) is the encapsulated random element.
        if self._confirm(recovered, package.associated) != package.confirmation:
            raise ValueError("The transform failed key confirmation")
        return AESGCM(self._key(recovered, package.associated)).decrypt(
            package.nonce, package.encrypted, package.associated)

    def direct_recover(self, package, gid, keys):
        G = self.group
        H = G.identity_hash(gid)
        P = self.transform(package, H, keys)
        return self.recover(package, P, 1, keys)
