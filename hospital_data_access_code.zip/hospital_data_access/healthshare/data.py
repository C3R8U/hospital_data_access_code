"""Clinical data profiling and attribute token construction."""
from __future__ import annotations
import json
import random
from pathlib import Path
import pandas as pd

FEATURE_QUOTAS = {
    "race": 6, "gender": 3, "age": 10, "admission_type_id": 8,
    "admission_source_id": 10, "discharge_disposition_id": 10,
    "medical_specialty": 10, "diag_1": 16, "A1Cresult": 4,
    "max_glu_serum": 4, "diabetesMed": 2, "insulin": 4,
    "readmitted": 3, "time_in_hospital_bin": 4,
    "num_lab_procedures_bin": 4, "num_medications_bin": 4,
    "payer_code": 4, "change": 2,
}
SYSTEM_TOKENS = (
    "role=clinician", "role=nurse", "role=researcher", "role=administrator",
    "purpose=treatment", "purpose=research", "purpose=operations",
    "channel=clinical", "channel=laboratory", "channel=administrative",
    "organization=org_a", "organization=org_b",
)


def load_data(path: str | Path) -> pd.DataFrame:
    # The string "None" is a real assay category, not a null marker.
    df = pd.read_csv(path, keep_default_na=False, low_memory=False)
    needed = {"encounter_id", "patient_nbr", "readmitted", "age", "diag_1"}
    if not needed.issubset(df.columns):
        raise ValueError(f"Missing columns: {sorted(needed - set(df.columns))}")
    return df


def add_bins(df):
    d = df.copy()
    for source, cutoffs in (
        ("time_in_hospital", [2, 5, 9]),
        ("num_lab_procedures", [20, 40, 60]),
        ("num_medications", [5, 10, 20]),
    ):
        d[source + "_bin"] = pd.cut(pd.to_numeric(d[source]),
            bins=[-float("inf"), *cutoffs, float("inf")],
            labels=["low", "lower_mid", "upper_mid", "high"],
            include_lowest=True).astype(str)
    return d


def normalize(v): return str(v).strip().replace(" ", "_")


def build_catalog(df):
    tokens, details = [], []
    for name, quota in FEATURE_QUOTAS.items():
        counts = df[name].astype(str).value_counts(dropna=False)
        ranked = sorted(counts.items(), key=lambda x: (-int(x[1]), str(x[0])))
        if len(ranked) < quota:
            raise ValueError(f"Not enough observed categories in {name}")
        for val, n in ranked[:quota]:
            text = f"{name}={normalize(val)}"
            tokens.append(text)
            details.append({"token": text, "source": name, "observations": int(n)})
    if len(tokens) != 108:
        raise ValueError(f"Expected 108 clinical attributes, got {len(tokens)}")
    for attr in SYSTEM_TOKENS:
        tokens.append(attr)
        details.append({"token": attr, "source": "authorization", "observations": None})
    if len(tokens) != 120 or len(set(tokens)) != 120:
        raise ValueError("Universal attribute dictionary must have 120 entries")
    return tokens, details


def record_attributes(row, universe, channel="clinical"):
    attrs = {f"{k}={normalize(row[k])}" for k in FEATURE_QUOTAS}
    attrs.update({"role=clinician", "purpose=treatment", "organization=org_a",
                  "channel=" + channel})
    return attrs & set(universe)


def patient_payload(row, length=2048):
    # The payload omits encounter and patient identifiers.
    names = ["race", "gender", "age", "admission_type_id", "admission_source_id",
             "discharge_disposition_id", "time_in_hospital", "medical_specialty",
             "num_lab_procedures", "num_medications", "diag_1", "diag_2", "diag_3",
             "A1Cresult", "max_glu_serum", "insulin", "readmitted"]
    raw = json.dumps({k: str(row[k]) for k in names},
                     separators=(",", ":"), sort_keys=True).encode("utf-8")
    if len(raw) > length: raise ValueError("Payload length is too short")
    return raw + b" " * (length - len(raw))


def describe(df):
    counts = df["readmitted"].value_counts()
    missing = {c: int((df[c].astype(str) == "?").sum()) for c in df.columns}
    return {"records": int(len(df)), "raw_columns": 50,
            "unique_encounters": int(df.encounter_id.nunique()),
            "unique_patients": int(df.patient_nbr.nunique()),
            "readmission_classes": {str(k): int(v) for k, v in counts.items()},
            "question_mark_missing": {k: v for k, v in missing.items() if v}}


def sample_records(df, n, seed):
    rng = random.Random(seed)
    return [(i, df.iloc[i].to_dict()) for i in rng.sample(range(len(df)), min(n, len(df)))]


def load_code_mapping(path):
    import csv
    sections = {}
    active = None
    with Path(path).open(newline="", encoding="utf-8") as file:
        for row in csv.reader(file):
            if not row or not row[0].strip():
                continue
            if row[0].endswith("_id") and len(row) > 1 and row[1] == "description":
                active = row[0]
                sections[active] = {}
            elif active and len(row) >= 2:
                sections[active][row[0].strip()] = ",".join(row[1:]).strip()
    return sections
