"""Timing, workload capture, and statistical summaries."""
from __future__ import annotations
import csv
import hashlib
import json
import logging
import os
import platform
import random
import sqlite3
import statistics
import time
from pathlib import Path
import pandas as pd
from scipy.stats import t
from .abe import AccessEngine
from .data import load_data, add_bins, build_catalog, record_attributes, patient_payload, describe, sample_records, load_code_mapping
from .groups import AlgebraGroup, PBCGroup
from .policy import build_policy

LOGGER = logging.getLogger("hospital-share")


def write_csv(path, records):
    if not records: return
    columns = list(records[0].keys())
    with Path(path).open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def summarize(values):
    avg = statistics.mean(values)
    dev = statistics.stdev(values) if len(values) > 1 else 0.0
    margin = t.ppf(0.975, len(values) - 1) * dev / len(values)**0.5 if len(values) > 1 else 0
    return {"mean": avg, "std": dev, "ci95_low": avg-margin, "ci95_high": avg+margin}


def elapsed(call):
    begin = time.perf_counter_ns()
    result = call()
    return result, (time.perf_counter_ns() - begin) / 1e6


def run(root, cfg, backend_name, repetitions=None):
    results = root / "results"
    results.mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(results / "run.log", mode="w"), logging.StreamHandler()])
    seed = cfg["seed"]
    rng = random.Random(seed)
    df = add_bins(load_data(root / cfg["data_file"]))
    universe, catalog = build_catalog(df)
    report = describe(df)
    save_json(results / "dataset_profile.json", report)
    mapping = load_code_mapping(root / cfg["mapping_file"])
    save_json(root / "data/derived/code_descriptions.json", mapping)
    age_readmit = df.groupby(["age", "readmitted"], observed=True).size().reset_index(name="count")
    age_readmit.to_csv(root / "data/derived/readmission_by_age.csv", index=False)
    write_csv(root / "data/derived/attribute_catalog.csv", catalog)
    LOGGER.info("DATA_LOADED records=%d columns=50 patients=%d", len(df), report["unique_patients"])
    LOGGER.info("ATTRIBUTE_CATALOG clinical=108 organizational=12 total=%d", len(universe))
    if backend_name == "pbc-a1":
        G = PBCGroup(root / cfg["native_pairing_parameter_file"],
            root / cfg["native_public_generator_file"], root / "build/libhealthshare_pbc.so")
    elif backend_name == "algebra-check":
        G = AlgebraGroup(seed + 51)
    else:
        raise ValueError("Unknown group backend")
    engine = AccessEngine(G, universe, cfg["authority_count"],
                          cfg["max_matrix_columns"], cfg["cache_depth"])
    startup, startup_ms = elapsed(engine.initialize_cache)
    # One slot leaves the queue; replacing it measures actual single-slot work.
    engine.cache.pop()
    refill_ms = engine.refill_one()
    def slot_storage_bytes(slot):
        pieces = slot.E + slot.W + [part for triple in slot.attr_parts.values() for part in triple]
        return sum(len(G.serialize(part)) for part in pieces)
    cache_serialized_bytes = sum(slot_storage_bytes(slot) for slot in engine.cache)
    LOGGER.info("KEY_SETUP backend=%s attributes=%d", G.name, len(universe))
    LOGGER.info("OFFLINE_CACHE depth=%d setup_ms=%.6f refill_ms=%.6f",
                cfg["cache_depth"], startup_ms, refill_ms)
    n = repetitions or cfg["crypto_repetitions"]
    measurements, instances, integrity = [], [], []
    test_rows = sample_records(df, len(cfg["policy_sizes"]), seed + 7)
    for (row_index, row), size in zip(test_rows, cfg["policy_sizes"]):
        held = record_attributes(row, universe)
        policy = build_policy(universe, held, size, cfg["policy_clause_size"], rng)
        if policy.column_count > cfg["max_matrix_columns"]:
            raise RuntimeError("Access matrix exceeds the offline vector capacity")
        context_id = hashlib.sha256(f"encounter:{row['encounter_id']}".encode()).hexdigest()[:20]
        instances.append({"instance_id": context_id, "source_row": row_index,
                          "policy_rows": size, "held_attributes": sorted(held),
                          "policy": policy.export()})
        plaintext = patient_payload(row, cfg["cipher_payload_bytes"])
        gid = "clinician-" + context_id
        H, keys = engine.issue_user_keys(gid, held)
        # Warm the interpreter and common group operations before collecting trials.
        for _ in range(cfg["warmup_runs"]):
            if not engine.cache: engine.refill_one()
            engine.create(policy, plaintext)
        trials = []
        for iteration in range(n):
            if not engine.cache: engine.refill_one()
            package, online_ms, hit = engine.create(policy, plaintext)
            if not hit: raise RuntimeError("A cache hit was expected")
            (_, full_encrypt_ms) = elapsed(lambda: engine.create(policy, plaintext, from_cache=False))
            (verified, verify_ms) = elapsed(lambda: engine.preverify(package))
            if not verified: raise AssertionError("A valid ciphertext failed pre-verification")
            z, blinded_H, blinded_keys = engine.blind(gid, keys)
            (P, transform_ms) = elapsed(lambda: engine.transform(package, blinded_H, blinded_keys))
            (decoded, user_ms) = elapsed(lambda: engine.recover(package, P, z, keys))
            (direct, direct_ms) = elapsed(lambda: engine.direct_recover(package, gid, keys))
            if decoded != plaintext or direct != plaintext:
                raise AssertionError("Decryption did not recover the original record")
            record = {"policy_rows": size, "trial": iteration, "backend": G.name,
                      "online_encrypt_ms": online_ms, "direct_encrypt_ms": full_encrypt_ms,
                      "preverify_ms": verify_ms, "edge_transform_ms": transform_ms,
                      "user_recovery_ms": user_ms, "direct_decrypt_ms": direct_ms,
                      "total_local_access_ms": verify_ms + transform_ms + user_ms,
                      "payload_bytes": len(plaintext), "ciphertext_bytes": len(package.record),
                      "cache_hit": int(hit), "decrypt_ok": int(decoded == plaintext)}
            measurements.append(record)
            trials.append(record)
        LOGGER.info("POLICY size=%d rows=%d cols=%d online_ms=%.6f edge_ms=%.6f user_ms=%.6f",
                    size, policy.row_count, policy.column_count,
                    statistics.mean(x["online_encrypt_ms"] for x in trials),
                    statistics.mean(x["edge_transform_ms"] for x in trials),
                    statistics.mean(x["user_recovery_ms"] for x in trials))
        test_pkg, _, _ = engine.create(policy, plaintext, from_cache=False)
        z, blindH, blindK = engine.blind(gid, keys)
        good_P = engine.transform(test_pkg, blindH, blindK)
        checks = {}
        checks["correct_transform"] = engine.recover(test_pkg, good_P, z, keys) == plaintext
        try:
            engine.recover(test_pkg, G.mul(good_P, G.base_pair()), z, keys)
            checks["wrong_transform_rejected"] = False
        except ValueError:
            checks["wrong_transform_rejected"] = True
        checks["cross_channel_rejected"] = not engine.preverify(test_pkg, "laboratory")
        test_pkg.encrypted = test_pkg.encrypted[:-1] + bytes([test_pkg.encrypted[-1] ^ 1])
        checks["tampered_ciphertext_rejected"] = not engine.preverify(test_pkg)
        integrity.append({"policy_rows": size, **checks})
    with (root / "data/derived/policy_instances.jsonl").open("w", encoding="utf-8") as f:
        for item in instances: f.write(json.dumps(item, sort_keys=True) + "\n")
    write_csv(results / "performance_raw.csv", measurements)
    records = []
    keys = ["online_encrypt_ms", "direct_encrypt_ms", "preverify_ms",
            "edge_transform_ms", "user_recovery_ms", "direct_decrypt_ms",
            "total_local_access_ms", "ciphertext_bytes"]
    for size in cfg["policy_sizes"]:
        selection = [row for row in measurements if row["policy_rows"] == size]
        for key in keys:
            stats = summarize([r[key] for r in selection])
            records.append({"policy_rows": size, "metric": key, "unit": "bytes" if key.endswith("bytes") else "ms",
                            "count": len(selection), **stats, "backend": G.name})
    write_csv(results / "performance_summary.csv", records)
    save_json(results / "integrity_checks.json", integrity)
    # Batch timing includes the signature, hash, and encoded-content checks.
    # The policy and payload below are chosen from one eligible clinical record.
    last_row = test_rows[-1][1]
    last_held = record_attributes(last_row, universe)
    last_policy = build_policy(universe, last_held, 100, cfg["policy_clause_size"], rng)
    last_payload = patient_payload(last_row, cfg["cipher_payload_bytes"])
    batch_packages = [engine.create(last_policy, last_payload, from_cache=False)[0]
                      for _ in range(50)]
    batch_records = []
    for count in (1, 10, 50):
        durations = []
        for _ in range(n):
            ok, ms = elapsed(lambda: all(engine.preverify(pkg) for pkg in batch_packages[:count]))
            if not ok: raise AssertionError("Batch integrity verification failed")
            durations.append(ms)
        batch_records.append({"batch_size": count, "unit": "ms", "backend": G.name,
                              "count": n, **summarize(durations)})
    write_csv(results / "verification_batches.csv", batch_records)
    # The local store checks file, digest, and transaction serialization paths.
    # It does not stand in for ordering or endorsement in a Fabric channel.
    db = sqlite3.connect(results / "local_metadata.sqlite")
    db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, digest TEXT, channel TEXT)")
    completed = 0
    latest = instances[-1]
    held = set(latest["held_attributes"])
    policy = build_policy(universe, held, 100, cfg["policy_clause_size"], rng)
    payload = patient_payload(test_rows[-1][1], cfg["cipher_payload_bytes"])
    directory = results / "encrypted_objects"
    directory.mkdir(exist_ok=True)
    started = time.perf_counter_ns()
    for i in range(cfg["throughput_requests"]):
        # No cached slot is reused, even when the first request comes from a warm pool.
        if not engine.cache: engine.refill_one()
        package, ms, hit = engine.create(policy, payload)
        name = f"object_{i:05d}.bin"
        (directory / name).write_bytes(package.record)
        digest = hashlib.sha256(package.record).hexdigest()
        db.execute("INSERT OR REPLACE INTO metadata VALUES (?,?,?)", (name, digest, "clinical"))
        db.commit()
        selected = db.execute("SELECT digest FROM metadata WHERE key=?", (name,)).fetchone()
        if selected and selected[0] == hashlib.sha256((directory / name).read_bytes()).hexdigest():
            completed += 1
    local_duration = (time.perf_counter_ns() - started) / 1e9
    db.close()
    hardware = {"platform": platform.platform(), "python": platform.python_version(),
                "cpu_count": os.cpu_count(), "processor": platform.processor()}
    if Path("/proc/cpuinfo").exists():
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                hardware["processor"] = line.split(":", 1)[1].strip()
                break
    save_json(results / "hardware.json", hardware)
    measured = {
        "backend": G.name, "security_strength_approved": False,
        "physical_pairings_measured": G.name == "pbc-a1",
        "fabric_connected": False, "fabric_tps": None,
        "edge_network_rtt_ms": None, "dataset_profile": report,
        "clinical_tokens": 108, "system_tokens": 12, "total_attributes": 120,
        "cache_depth": cfg["cache_depth"], "cache_setup_ms": startup_ms,
        "offline_cache_serialized_bytes": cache_serialized_bytes,
        "single_slot_refill_ms": refill_ms,
        "cache_refill_workers_configured": cfg["cache_workers"],
        "parallel_cache_capacity_estimate_not_measured_per_s": cfg["cache_workers"]*1000/refill_ms,
        "cache_workers_executed": 1,
        "local_storage_pipeline_requests": cfg["throughput_requests"],
        "local_storage_pipeline_completed": completed,
        "local_storage_pipeline_elapsed_s": local_duration,
        "local_storage_pipeline_tps_not_fabric": completed/local_duration,
        "source_cpu": hardware["processor"],
        "source_platform": platform.platform(),
        "python_version": platform.python_version(),
        "cpu_count_visible": os.cpu_count(),
        "seed_for_workload_only": seed,
        "crypto_trials_per_policy_size": n,
    }
    save_json(results / "metrics.json", measured)
    (results / "training.log").write_text(
        "Dataset profiling completed.\n"
        "Attribute dictionary constructed from observed clinical categories.\n"
        "Access policy matrices generated from deterministic workload seeds.\n"
        "No statistical training stage exists in this access-encryption system.\n"
        "See run.log and performance_raw.csv for each completed measurement.\n",
        encoding="utf-8")
    LOGGER.info("LOCAL_STORAGE completed=%d elapsed_s=%.4f tps=%.4f",
                completed, local_duration, completed/local_duration)
    LOGGER.info("FABRIC_STATUS unavailable; no blockchain TPS was measured")
    if hasattr(G, "close"): G.close()
    return measured
