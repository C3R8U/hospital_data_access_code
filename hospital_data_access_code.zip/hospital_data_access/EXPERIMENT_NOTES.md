# Hospital Data Access Bench

The data access layer uses a multi-authority monotone LSSS policy, independent
one-use offline encryption tuples, blinded pairing transformation, AES-128-GCM,
Ed25519 signatures, and SHA-256 integrity checks.

## Input files

- `data/raw/diabetic_data.csv`: hospital encounter records.
- `data/raw/IDS_mapping.csv`: original categorical code descriptions.
- `config/study.json`: seed, attribute universe size, access policies, pairing
  target parameters, cache controls, and benchmark repetitions.

The 120 authorization attributes consist of 108 frequent clinical categories and
12 administrative attributes. The token dictionary is saved under
`data/derived/attribute_catalog.csv`. Policy conditions are derived from
categorical fields and user authorization context; readmission classes are not
prediction targets. There is no classification or regression training step.

## Available execution modes

`algebra-check` uses a compact exponent representation to test algebraic
identities and code paths. This mode cannot establish cryptographic security,
physical pairing performance, or production encryption throughput.

`pbc-a1` uses the native PBC pairing library. Install PBC 0.5.14 and GMP on the
machine that will execute native workloads. Then run:

```bash
bash scripts/build_native.sh
python scripts/create_pairing_parameters.py --bits 1024
python scripts/run_experiment.py --backend pbc-a1
```

The PBC parameter generator keeps subgroup factors out of the public output.
Do not publish factor files, private user keys, or plaintext medical records.
Assess the full pairing curve and target finite field before claiming a
cryptographic security level. A 3072-bit composite group order alone does not
prove 128-bit security.

For algebra and application control-flow tests:

```bash
python -m pytest -q tests/
python scripts/run_experiment.py --backend algebra-check
python scripts/make_figures.py
python scripts/summarize_results.py
```

## Produced files

- `results/run.log`: initialization, workload progress, and environment status.
- `results/training.log`: dataset and attribute-policy build stages. No model is fit.
- `results/performance_raw.csv`: individual operation timings.
- `results/performance_summary.csv`: means, sample SD, and 95% intervals.
- `results/metrics.json`: corpus facts, cache timing, local pipeline, hardware.
- `results/dataset_profile.json`: dataset counts and missing category counts.
- `results/integrity_checks.json`: invalid transform and cross-channel checks.
- `results/local_metadata.sqlite`: local transaction records for storage checks.
- `results/figures/`: operation timings and ciphertext size.
- `data/derived/policy_instances.jsonl`: generated matrices and user attributes.

## Deployment measurements

The test process only reports operations that it actually executes. Local SQLite
storage is useful for checking the path from encryption to a signed digest,
but is not a Hyperledger Fabric orderer or endorsement service. Independent
Fabric measurements require a running Fabric network and the separately
provided chaincode and gateway client. CPU values and confidence intervals
refer to the host that ran the experiments, not to an Intel i9 or a VM unless
that is the host actually used.

## Metadata channels

The gateway client reads encrypted transaction templates from
`data/derived/fabric_transactions.jsonl`. Run:

```bash
python scripts/build_fabric_workload.py --count 150 --backend pbc-a1
python scripts/ipfs_upload.py --endpoint http://127.0.0.1:5001
cd scripts && npm install
FABRIC_REQUIRE_IPFS=1 node fabric_load.js
```

The chaincode under `chaincode/metadata/` must be deployed on all three
channels before starting the gateway client. Set the peer endpoint, identity
certificate, identity private key, TLS certificate, and MSP identifier through
the documented environment variables in the JavaScript source. The gateway
logs confirmed transactions, not merely queued submissions. The prepared
metadata inputs use actual signed encrypted hospital records. Nonproduction
algebra-check inputs are suitable for connectivity tests, not patient-data
security claims.

See `MODEL_SPEC.md` for the group identities, key construction, LSSS shares,
ciphertext components, and timing boundaries.
