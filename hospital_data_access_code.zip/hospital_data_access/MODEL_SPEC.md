# Cryptographic and Workload Specification

## Study configuration

- Public corpus: UCI Diabetes 130-US Hospitals for Years 1999–2008.
- Original data: 101,766 encounters, 50 file columns.
- Attribute dictionary: 108 data-derived tokens and 12 institutional tokens.
- Authorities: four independently keyed attribute domains.
- Policy sizes: 20, 40, 60, 80, and 100 unique leaf attributes.
- Access formula: conjunction of OR clauses, at most 20 leaves per clause.
- LSSS coefficients: -1, 0, or 1; column count bounded by 16.
- Online cache: eight disposable slots, 20% refill threshold.
- Target pairing: symmetric type A1 over N = p1 * p2 * p3,
  with independently generated 1024-bit prime factors.
- Security target: 128 bits, subject to independent full parameter assessment.
- Bulk data encryption: AES-128-GCM with a 96-bit nonce.
- Data integrity: Ed25519 owner signatures and SHA-256 package digests.
- Key derivation: HKDF-SHA256 with channel and policy context.

## Authority and user keys

For each attribute x, an authority picks alpha_x and y_x in Z_N, publishes
A_x = e(g,g)^alpha_x and B_x = g^y_x, and issues

```
SK[u,x] = g^alpha_x * H(GID_u)^y_x
```

Here g is a generator of the p1-subgroup, and H maps user identities to G.
User key components are issued under a common registered identity.

## Policy matrix and offline shares

The access matrix M contains one row for each uniquely labeled leaf.
An AND node allocates one new column: its left child receives v + e_j and
its right child receives -e_j. An OR node copies the parent vector to each
child. The reconstruction coefficients are the selected leaves in every OR
clause, giving the integer identity sum_i gamma_i M_i = (1,0,...,0).

A disposable offline slot holds independent vectors

```
v = (s, v2, ..., vD)
w = (0, w2, ..., wD)
E_j = e(g,g)^v_j
W_1 = 1; W_j = g^w_j
X_x = A_x^r_x
Y_x = g^r_x
Z_x = B_x^r_x
```

The policy shares are lambda_i = M_i v and omega_i = M_i w.
The online operation combines precomputed elements using the -1/0/1
matrix coefficients:

```
C1_i = X_rho(i) * product_j E_j^M_ij
C2_i = Y_rho(i)
C3_i = Z_rho(i) * product_{j>=2} W_j^M_ij
C0   = R * E_1
```

The identity `C1_i = e(g,g)^(lambda_i + alpha_x r_x)` follows directly.
`C3_i = g^(omega_i + y_x r_x)` supplies the cancellation term.

A random R in GT supplies HKDF material for the AES-GCM content key.
The associated data binds channel, policy digest, and object version.
The signed ciphertext record contains the encrypted content, the full
attribute ciphertext, the policy matrix, and the secret-independent key
confirmation digest. Offline randomness is never serialized as a secret.

## Edge-assisted recovery

The user chooses invertible z in Z_N and delegates blinded values

```
TK[u,x] = SK[u,x]^(1/z)
TK[H]   = H(GID_u)^(1/z)
P       = product_{i in I} (e(TK[H],C3_i) / e(TK[u,rho(i)],C2_i))^gamma_i
L       = product_{i in I} C1_i^gamma_i
Z       = L * P^z = e(g,g)^s
R       = C0 / Z
```

A mismatched transform produces a different R and fails the confirmation
check or AES-GCM authentication. The signed ciphertext digest is validated
before a remote transform is accepted. Policy failure is not an authentication
failure; it is a denial of attribute access.

## Metric definitions

`online_encrypt_ms` measures only the online stage after a valid slot was
obtained. `direct_encrypt_ms` includes fresh slot construction and online
work. `edge_transform_ms` measures the transform on the active host.
`user_recovery_ms` measures the local exponentiation and AES recovery.
`total_local_access_ms` adds verification, transform, and local recovery;
it excludes IPFS network and Fabric query latency.

`local_storage_pipeline_tps_not_fabric` measures local file persistence and
SQLite metadata confirmation with encryption. It is not a blockchain TPS
measurement. `fabric_commits.json` can be produced only by an active
Fabric Gateway connection with the configured network and deployed chaincode.

The algebra-check backend never invokes a physical pairing and must not be
used to infer a security strength or performance of A1 pairing arithmetic.
