"""Checks encryption arithmetic and rejection paths on deterministic fixtures."""
import random
import pytest
from healthshare.groups import AlgebraGroup
from healthshare.policy import build_policy
from healthshare.abe import AccessEngine

@pytest.fixture
def prepared():
    universe = [f"a{i:03d}" for i in range(120)]
    owned = set(universe[::5])
    group = AlgebraGroup(seed=55)
    engine = AccessEngine(group, universe, cache_depth=2)
    engine.initialize_cache()
    policy = build_policy(universe, owned, 100, 20, random.Random(13))
    plain = b"Protected hospital encounter" * 20
    package, elapsed, hit = engine.create(policy, plain)
    return engine, group, universe, owned, policy, plain, package

def test_lsss_reconstruction(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    assert policy.column_count == 5
    assert policy.witness(owned) is not None
    assert policy.witness(set()) is None
    assert all(v in (-1, 0, 1) for r in policy.matrix for v in r)

def test_blinded_recovery(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    H, keys = engine.issue_user_keys("doctor-001", owned)
    z, H_bl, K_bl = engine.blind("doctor-001", keys)
    transformed = engine.transform(package, H_bl, K_bl)
    assert engine.preverify(package)
    assert engine.recover(package, transformed, z, keys) == plain
    assert engine.direct_recover(package, "doctor-001", keys) == plain

def test_invalid_transformation(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    H, keys = engine.issue_user_keys("doctor-001", owned)
    z, H_bl, K_bl = engine.blind("doctor-001", keys)
    invalid = group.mul(engine.transform(package, H_bl, K_bl), group.base_pair())
    with pytest.raises(ValueError): engine.recover(package, invalid, z, keys)

def test_unauthorized_and_cross_channel(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    H, keys = engine.issue_user_keys("visitor", set())
    with pytest.raises(PermissionError): engine.transform(package, H, keys)
    assert not engine.preverify(package, "laboratory")

def test_mixed_identity_keys_rejected(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    first = {x for i, x in enumerate(sorted(owned)) if i % 2 == 0}
    second = owned - first
    h1, k1 = engine.issue_user_keys("doctor-1", first)
    _, k2 = engine.issue_user_keys("doctor-2", second)
    mixed = dict(k1)
    mixed.update(k2)
    p = engine.transform(package, h1, mixed)
    with pytest.raises(ValueError): engine.recover(package, p, 1, mixed)

def test_changed_ciphertext_rejected(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    package.encrypted = package.encrypted[:-1] + bytes([package.encrypted[-1] ^ 1])
    assert not engine.preverify(package)

def test_signed_package_storage_roundtrip(prepared):
    engine, group, universe, owned, policy, plain, package = prepared
    stored = engine.load_signed_package(package.record, package.signature,
                                        engine.signer.public_key())
    H, keys = engine.issue_user_keys("doctor-001", owned)
    z, H_bl, K_bl = engine.blind("doctor-001", keys)
    P = engine.transform(stored, H_bl, K_bl)
    assert engine.recover(stored, P, z, keys) == plain


def test_external_signer_not_trusted(prepared):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    engine, group, universe, owned, policy, plain, package = prepared
    attacker = Ed25519PrivateKey.generate()
    forged = attacker.sign(package.record)
    with pytest.raises(Exception):
        engine.load_signed_package(package.record, forged, engine.signer.public_key())
