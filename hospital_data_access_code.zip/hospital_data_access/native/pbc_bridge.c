/* A small lifetime-managed wrapper around the PBC element API. */
#include <pbc/pbc.h>
#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Entry {
    element_t value;
    int kind;
    struct Entry *next;
} Entry;

typedef struct {
    pairing_t pairing;
    Entry *head;
    Entry *generator;
    char *order_hex;
} Context;

static char *load_file(const char *path, size_t *size) {
    FILE *in = fopen(path, "rb");
    if (!in) return NULL;
    if (fseek(in, 0, SEEK_END)) { fclose(in); return NULL; }
    long n = ftell(in);
    if (n <= 0 || n > 10000000) { fclose(in); return NULL; }
    rewind(in);
    char *data = calloc((size_t)n + 1, 1);
    if (!data || fread(data, 1, (size_t)n, in) != (size_t)n) {
        free(data); fclose(in); return NULL;
    }
    fclose(in);
    *size = (size_t)n;
    return data;
}

static Entry *make_element(Context *ctx, int kind) {
    Entry *item = calloc(1, sizeof(*item));
    if (!item) return NULL;
    if (kind == 1) element_init_G1(item->value, ctx->pairing);
    else if (kind == 2) element_init_GT(item->value, ctx->pairing);
    else { free(item); return NULL; }
    item->kind = kind;
    item->next = ctx->head;
    ctx->head = item;
    return item;
}

static char *read_order_hex(const char *data) {
    const char *line = data;
    while (*line) {
        if (line[0] == 'n' && line[1] == ' ') {
            const char *start = line + 2;
            const char *end = start;
            while (*end >= '0' && *end <= '9') end++;
            if (end == start) return NULL;
            size_t len = (size_t)(end - start);
            char *decimal = malloc(len + 1);
            if (!decimal) return NULL;
            memcpy(decimal, start, len);
            decimal[len] = 0;
            mpz_t value;
            mpz_init(value);
            int status = mpz_set_str(value, decimal, 10);
            free(decimal);
            if (status) { mpz_clear(value); return NULL; }
            char *hex = mpz_get_str(NULL, 16, value);
            mpz_clear(value);
            return hex;
        }
        while (*line && *line != '\n') line++;
        if (*line) line++;
    }
    return NULL;
}

void hs_close(void *pointer);

void *hs_open(const char *param_file, const char *generator_file) {
    size_t len = 0, glen = 0;
    char *params = load_file(param_file, &len);
    unsigned char *gbytes = (unsigned char *)load_file(generator_file, &glen);
    if (!params || !gbytes) { free(params); free(gbytes); return NULL; }
    Context *ctx = calloc(1, sizeof(*ctx));
    if (!ctx) { free(params); free(gbytes); return NULL; }
    ctx->order_hex = read_order_hex(params);
    if (!ctx->order_hex || pairing_init_set_buf(ctx->pairing, params, len)) {
        free(ctx->order_hex); free(ctx); free(params); free(gbytes); return NULL;
    }
    free(params);
    if (!pairing_is_symmetric(ctx->pairing)) {
        free(gbytes); hs_close(ctx); return NULL;
    }
    ctx->generator = make_element(ctx, 1);
    if (!ctx->generator || glen != (size_t)element_length_in_bytes(ctx->generator->value)) {
        free(gbytes); hs_close(ctx); return NULL;
    }
    if (element_from_bytes(ctx->generator->value, gbytes) < 0 ||
        element_is1(ctx->generator->value)) {
        free(gbytes); hs_close(ctx); return NULL;
    }
    free(gbytes);
    return ctx;
}

void hs_close(void *pointer) {
    Context *ctx = (Context *)pointer;
    if (!ctx) return;
    Entry *node = ctx->head;
    while (node) {
        Entry *next = node->next;
        element_clear(node->value);
        free(node);
        node = next;
    }
    pairing_clear(ctx->pairing);
    free(ctx->order_hex);
    free(ctx);
}

const char *hs_order(void *pointer) { return ((Context *)pointer)->order_hex; }
void *hs_generator(void *pointer) { return ((Context *)pointer)->generator; }

void *hs_identity(void *pointer, int kind) {
    Entry *out = make_element(pointer, kind);
    if (out) element_set1(out->value);
    return out;
}

void *hs_gid_hash(void *pointer, const char *gid) {
    Entry *out = make_element(pointer, 1);
    if (out) {
        size_t n = strlen(gid) + 4;
        char *buf = malloc(n + 1);
        if (!buf) return NULL;
        snprintf(buf, n + 1, "ID:%s", gid);
        element_from_hash(out->value, buf, strlen(buf));
        free(buf);
    }
    return out;
}

void *hs_random_target(void *pointer) {
    Entry *out = make_element(pointer, 2);
    if (out) element_random(out->value);
    return out;
}

void *hs_mul(void *pointer, void *a, void *b) {
    Entry *x = a, *y = b;
    if (!x || !y || x->kind != y->kind) return NULL;
    Entry *out = make_element(pointer, x->kind);
    if (out) element_mul(out->value, x->value, y->value);
    return out;
}

void *hs_div(void *pointer, void *a, void *b) {
    Entry *x = a, *y = b;
    if (!x || !y || x->kind != y->kind) return NULL;
    Entry *out = make_element(pointer, x->kind);
    if (out) element_div(out->value, x->value, y->value);
    return out;
}

void *hs_pow(void *pointer, void *a, const char *scalar) {
    Entry *x = a;
    if (!x) return NULL;
    mpz_t exponent;
    mpz_init(exponent);
    if (mpz_set_str(exponent, scalar, 10)) { mpz_clear(exponent); return NULL; }
    Entry *out = make_element(pointer, x->kind);
    if (out) element_pow_mpz(out->value, x->value, exponent);
    mpz_clear(exponent);
    return out;
}

void *hs_pair(void *pointer, void *a, void *b) {
    Entry *x = a, *y = b;
    if (!x || !y || x->kind != 1 || y->kind != 1) return NULL;
    Context *ctx = pointer;
    Entry *out = make_element(ctx, 2);
    if (out) pairing_apply(out->value, x->value, y->value, ctx->pairing);
    return out;
}

int hs_byte_length(void *ptr) { return ptr ? element_length_in_bytes(((Entry *)ptr)->value) : -1; }
int hs_to_bytes(void *ptr, void *buf, int capacity) {
    if (!ptr || !buf) return -1;
    int length = hs_byte_length(ptr);
    if (length > capacity) return -1;
    return element_to_bytes(buf, ((Entry *)ptr)->value);
}

void *hs_from_bytes(void *pointer, int kind, const void *buf, int capacity) {
    if (!pointer || !buf) return NULL;
    Entry *result = make_element(pointer, kind);
    if (!result) return NULL;
    int needed = element_length_in_bytes(result->value);
    if (capacity != needed) return NULL;
    if (element_from_bytes(result->value, (unsigned char *)buf) < 0) return NULL;
    return result;
}
