/* Generates the public A1 parameters and a generator of the selected subgroup. */
#include <pbc/pbc.h>
#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stderr, "Usage: setup_a1 private_primes.txt public_params.txt public_generator.bin\n");
        return 2;
    }
    FILE *secret = fopen(argv[1], "r");
    if (!secret) return 2;
    mpz_t p1, p2, p3, n, cofactor;
    mpz_inits(p1, p2, p3, n, cofactor, NULL);
    int ok = gmp_fscanf(secret, "%Zd\n%Zd\n%Zd", p1, p2, p3);
    fclose(secret);
    if (ok != 3) { fprintf(stderr, "Invalid prime input\n"); return 2; }
    mpz_mul(n, p1, p2);
    mpz_mul(n, n, p3);
    mpz_mul(cofactor, p2, p3);
    pbc_param_t params;
    pbc_param_init_a1_gen(params, n);
    FILE *out = fopen(argv[2], "w");
    if (!out) return 2;
    pbc_param_out_str(out, params);
    fclose(out);
    FILE *param_file = fopen(argv[2], "rb");
    fseek(param_file, 0, SEEK_END);
    long length = ftell(param_file);
    rewind(param_file);
    char *buffer = malloc((size_t)length);
    if (!buffer || fread(buffer, 1, (size_t)length, param_file) != (size_t)length) return 2;
    fclose(param_file);
    pairing_t pairing;
    if (pairing_init_set_buf(pairing, buffer, (size_t)length)) return 2;
    free(buffer);
    element_t g;
    element_init_G1(g, pairing);
    do {
        element_random(g);
        element_pow_mpz(g, g, cofactor);
    } while (element_is1(g));
    size_t bytes = (size_t)element_length_in_bytes(g);
    unsigned char *encoded = malloc(bytes);
    element_to_bytes(encoded, g);
    out = fopen(argv[3], "wb");
    if (!out || fwrite(encoded, 1, bytes, out) != bytes) return 2;
    fclose(out);
    free(encoded);
    element_clear(g);
    pairing_clear(pairing);
    pbc_param_clear(params);
    mpz_clears(p1, p2, p3, n, cofactor, NULL);
    return 0;
}
